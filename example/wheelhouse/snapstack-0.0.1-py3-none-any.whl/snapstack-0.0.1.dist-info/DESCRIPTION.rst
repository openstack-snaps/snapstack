# snapstack
Integration Testing Harness for Openstack Snaps [Prototype]

This is a first pass at an Integration Testing Harness for Openstack Snaps, intended for use in the Canonical Openstack Team's CI system.

Usually, this testing harness would be imported into a test in the same repo as the snapcraft.yaml for an individual test. A developer would then be able to run the tests with tox.


